import 'dart:io';

import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:badges/badges.dart';
import 'package:fluttertoast/fluttertoast.dart';

// My Own Import
import 'package:q_mart/pages/home_page_component/drawer.dart';
import 'package:q_mart/pages/home_page_component/category_grid.dart';
import 'package:q_mart/pages/home_page_component/best_offer_grid.dart';
import 'package:q_mart/pages/home_page_component/top_seller_grid.dart';
import 'package:q_mart/pages/home_page_component/best_deal.dart';
import 'package:q_mart/pages/home_page_component/featured_brands.dart';
import 'package:q_mart/pages/home_page_component/block_buster_deal.dart';
import 'package:q_mart/pages/home_page_component/best_of_fashion.dart';
import 'package:q_mart/pages/home_page_component/womens_collection.dart';
import 'package:q_mart/pages/notifications.dart';
import 'package:q_mart/pages/category/top_offers.dart';
import 'package:q_mart/Animation/slide_left_rout.dart';
import 'package:q_mart/pages/cart.dart';
import 'package:q_mart/pages/search.dart';

class Home extends StatefulWidget {
  Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  DateTime currentBackPressTime;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      appBar: AppBar(
        centerTitle: true,
        title: Text(
          'Q mart',
          style: TextStyle(
            fontFamily: 'Montserrat', //Montserrat-BoldItalic.ttf //Poppins
          ),
        ),
        titleSpacing: 0.0,
        backgroundColor: Theme.of(context).primaryColor,
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.search),
            color: Theme.of(context).cardColor,
            onPressed: () {
              Navigator.push(context,
                  MaterialPageRoute(builder: (context) => SearchPage()));
            },
          ),
          IconButton(
            icon: Badge(
              badgeContent: Text('3'),
              badgeColor: Theme.of(context).primaryColorLight,
              child: Icon(
                Icons.shopping_cart,
                color: Theme.of(context).cardColor,
              ),
            ),
            onPressed: () {
              Navigator.push(context, SlideLeftRoute(page: CartPage()));
            },
          ),
          IconButton(
            icon: Badge(
              badgeContent: Text('2'),
              badgeColor: Theme.of(context).primaryColorLight,
              child: Icon(
                Icons.notifications,
                color: Theme.of(context).cardColor,
              ),
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Notifications()),
              );
            },
          ),
        ],
      ),

      // Drawer Code Start Here

      drawer: MainDrawer(),

      // Drawer Code End Here
      body: WillPopScope(
        child: ListView(
          physics: BouncingScrollPhysics(),
          children: <Widget>[
            SizedBox(
              height: 12,
            ),

            // Slider Code Start Here
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 2,

                shadowColor: Colors.black12,
                color: Theme.of(context).cardColor,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(7)
                ),

                child: Container(
                  decoration:

                  BoxDecoration(borderRadius: BorderRadius.circular(7)),
                  child: SizedBox(
                    height: 168.0,
                    child: Padding(
                      padding: const EdgeInsets.all(18.0),
                      child: Carousel(
                        radius: Radius.circular(7),
                        showIndicator: true,
                        images: [

                          AssetImage('assets/slider/bn-1.png'),
                          AssetImage('assets/slider/bn-2.png'),
                          AssetImage('assets/slider/bn-2.png'),
                          AssetImage('assets/slider/bn-1.png'),
                          AssetImage('assets/slider/bn-2.png'),
                          AssetImage('assets/slider/bn-2.png'),


                        ],
                        dotSize: 6.0,
                        indicatorBgPadding: 5.0,
                        dotSpacing: 15.0,
                        dotColor: Theme.of(context).primaryColor,
                        boxFit: BoxFit.fill,
                        dotVerticalPadding: 0.1,
                        dotPosition: DotPosition.bottomCenter,

                        animationCurve: Curves.decelerate,
                        dotBgColor: Colors.purple.withOpacity(0.0),
                        noRadiusForIndicator: true,
                        autoplay: true,
                        borderRadius: true,

                      ),
                    ),
                  ),
                ),
              ),
            ),

            // Slider Code End Here

            SizedBox(
              height: 5.0,
            ),

            // Category Grid Start Here
            CategoryGrid(),

            // Category Grid End Here

            SizedBox(
              height: 6.0,
            ),




            // Best Offer Grid Start Here

            BestOfferGrid(),

            // Best Offer Grid End Here
            SizedBox(
              height: 4.0,
            ),
            // Promotion 1 Start Here
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) =>
                          TopOffers(title: 'Top Selling Android Mobile')),
                );
              },
              child: Card(elevation: 0,
                color: Theme.of(context).backgroundColor,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20)
                ),
                child: Image(
                  image: AssetImage('assets/banner/pro-1.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            
            // // Promotion 1 End Here


            SizedBox(
              height: 4.2,
            ),

            // Top Seller Grid Start Here
            TopSeller(),
            // Top Seller Grid End Here

            SizedBox(
              height: 3.8,
            ),

            SizedBox(
              height: 4.0,
            ),

            // Best Deal Grid Start Here
            BestDealGrid(),
            // Best Deal Grid End Here

            SizedBox(
              height: 3.8,
            ),

            SizedBox(
              height: 8.0,
            ),

            // // Featured Brand Slider Start Here
            // FeaturedBrandSlider(),
            // // Featured Brand Slider End Here

            SizedBox(
              height: 6.0,
            ),

            SizedBox(
              height: 6.0,
            ),

            // Block Buster Deals Start Here
            BlockBusterDeals(),
            // Block Buster Deals End Here

            SizedBox(
              height: 6.0,
            ),

            SizedBox(
              height: 0.0,
            ),
            // Womens Collection Start Here
            WomensCollection(),
            // Womens Collection End Here

            SizedBox(
              height: 6.0,
            ),
            //Best of Fashion Start Here
            BestOfFashion(),
            //Best of Fashion End Here

            SizedBox(
              height: 0.0,
            ),

            SizedBox(height: 20.0),
          ],
        ),
        onWillPop: () async {
          bool backStatus = onWillPop();
          if (backStatus) {
            exit(0);
          }
          return false;
        },
      ),
    );
  }

  onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime) > Duration(seconds: 3)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(
        msg: 'Press Back Once Again to Exit.',
        backgroundColor: Colors.black,
        textColor: Colors.white,
      );
      return false;
    } else {
      return true;
    }
  }
}
