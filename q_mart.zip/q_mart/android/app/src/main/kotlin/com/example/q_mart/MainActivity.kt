package com.example.q_mart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
